package com.tutienda.inventario.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    // CAMBIA ESTOS DATOS
    private static final String URL = "jdbc:postgresql://localhost:5432/tienda_inventario";
    private static final String USER = "postgres";
    private static final String PASS = "postgres123";

    private static Connection conn;

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(URL, USER, PASS);
                System.out.println("Conectado a PostgreSQL OK");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
