package com.tutienda.inventario.dao;

import com.tutienda.inventario.model.Marca;
import com.tutienda.inventario.model.Producto;
import java.sql.*;
import java.util.*;

public class ProductoDAO {
    private Connection conn = ConexionDB.getConnection();

    public List<Producto> listar(String filtro, int page, int pageSize) {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT p.*, m.nombre as marca_nombre FROM productos p " +
                     "JOIN marcas m ON p.marca_id = m.id " +
                     "WHERE p.referencia ILIKE ? OR p.nombre ILIKE ? OR m.nombre ILIKE ? " +
                     "ORDER BY p.id LIMIT ? OFFSET ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + (filtro==null?"":filtro) + "%";
            ps.setString(1, like); ps.setString(2, like); ps.setString(3, like);
            ps.setInt(4, pageSize);
            ps.setInt(5, page * pageSize);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Producto p = new Producto();
                p.setId(rs.getInt("id"));
                p.setMarcaId(rs.getInt("marca_id"));
                p.setMarcaNombre(rs.getString("marca_nombre"));
                p.setReferencia(rs.getString("referencia"));
                p.setNombre(rs.getString("nombre"));
                p.setFotoRuta(rs.getString("foto_ruta"));
                p.setTallas(getTallas(p.getId()));
                lista.add(p);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    public int contar(String filtro){
        String sql = "SELECT COUNT(*) FROM productos p JOIN marcas m ON p.marca_id=m.id WHERE p.referencia ILIKE ? OR p.nombre ILIKE ? OR m.nombre ILIKE ?";
        try(PreparedStatement ps=conn.prepareStatement(sql)){
            String like="%"+(filtro==null?"":filtro)+"%";
            ps.setString(1,like); ps.setString(2,like); ps.setString(3,like);
            ResultSet rs=ps.executeQuery();
            if(rs.next()) return rs.getInt(1);
        }catch(Exception e){ e.printStackTrace();}
        return 0;
    }

    public Map<Integer,Integer> getTallas(int productoId){
        Map<Integer,Integer> map=new HashMap<>();
        String sql="SELECT talla,cantidad FROM inventario WHERE producto_id=?";
        try(PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setInt(1,productoId);
            ResultSet rs=ps.executeQuery();
            while(rs.next()) map.put(rs.getInt("talla"), rs.getInt("cantidad"));
        }catch(Exception e){ e.printStackTrace();}
        return map;
    }

    public void actualizarCantidad(int productoId, int talla, int cantidad){
        String sql="INSERT INTO inventario (producto_id, talla, cantidad) VALUES (?,?,?) ON CONFLICT (producto_id, talla) DO UPDATE SET cantidad=EXCLUDED.cantidad";
        try(PreparedStatement ps=conn.prepareStatement(sql)){
            ps.setInt(1,productoId); ps.setInt(2,talla); ps.setInt(3,cantidad);
            ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace();}
    }

    public void actualizarFoto(int productoId, String ruta){
        try(PreparedStatement ps=conn.prepareStatement("UPDATE productos SET foto_ruta=? WHERE id=?")){
            ps.setString(1,ruta); ps.setInt(2,productoId); ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace();}
    }

    public List<Marca> listarMarcas(){
        List<Marca> list=new ArrayList<>();
        try(Statement st=conn.createStatement(); ResultSet rs=st.executeQuery("SELECT * FROM marcas ORDER BY nombre")){
            while(rs.next()) list.add(new Marca(rs.getInt("id"), rs.getString("nombre")));
        }catch(Exception e){ e.printStackTrace();}
        return list;
    }

    public void crearProducto(String referencia, String nombre, int marcaId){
        try(PreparedStatement ps=conn.prepareStatement("INSERT INTO productos (referencia,nombre,marca_id) VALUES (?,?,?)")){
            ps.setString(1,referencia); ps.setString(2,nombre); ps.setInt(3,marcaId); ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace();}
    }

    public void crearMarca(String nombre){
        try(PreparedStatement ps=conn.prepareStatement("INSERT INTO marcas (nombre) VALUES (?) ON CONFLICT DO NOTHING")){
            ps.setString(1,nombre); ps.executeUpdate();
        }catch(Exception e){ e.printStackTrace();}
    }
}
