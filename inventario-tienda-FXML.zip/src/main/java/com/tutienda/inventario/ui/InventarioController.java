package com.tutienda.inventario.ui;

import com.tutienda.inventario.dao.ProductoDAO;
import com.tutienda.inventario.model.Marca;
import com.tutienda.inventario.model.Producto;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.util.converter.IntegerStringConverter;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class InventarioController {

    @FXML private TextField txtBuscar;
    @FXML private TableView<Producto> tabla;
    @FXML private Pagination pagination;
    @FXML private ComboBox<Marca> cbMarcas;
    @FXML private TextField txtRef, txtNombre, txtNuevaMarca;
    @FXML private Label lblInfo;

    private ProductoDAO dao = new ProductoDAO();
    private final int PAGE_SIZE = 8;

    @FXML
    public void initialize() {
        tabla.setEditable(true);
        txtBuscar.setPromptText("Buscar producto con su fila (ej: NIKE 001-808, ADIDAS BA2092)...");

        cargarMarcas();

        // Columna Marca/Referencia
        TableColumn<Producto, String> colRef = new TableColumn<>("MARCA / REFERENCIA");
        colRef.setPrefWidth(250);
        colRef.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getMarcaNombre() + " - " + c.getValue().getReferencia() + "\n" + c.getValue().getNombre()));
        
        TableColumn<Producto, ImageView> colFoto = new TableColumn<>("FOTO MODELO");
        colFoto.setPrefWidth(90);
        colFoto.setCellValueFactory(c -> {
            String ruta = c.getValue().getFotoRuta();
            ImageView iv = new ImageView();
            try {
                if(ruta!=null && !ruta.isEmpty()){
                    File f = new File(ruta);
                    if(f.exists()) iv.setImage(new Image(f.toURI().toString(), 70, 70, true, true));
                }
            } catch(Exception e){}
            return new SimpleObjectProperty<>(iv);
        });

        tabla.getColumns().add(colRef);

        // Columnas Tallas 34-45 editables
        for(int t=34; t<=45; t++){
            int talla = t;
            TableColumn<Producto, Integer> col = new TableColumn<>(String.valueOf(t));
            col.setPrefWidth(50);
            col.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getTallas().getOrDefault(talla, 0)));
            col.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
            col.setOnEditCommit(event -> {
                Producto prod = event.getRowValue();
                int nueva = event.getNewValue() == null ? 0 : event.getNewValue();
                dao.actualizarCantidad(prod.getId(), talla, nueva);
                prod.getTallas().put(talla, nueva);
                tabla.refresh();
            });
            tabla.getColumns().add(col);
        }

        TableColumn<Producto, Integer> colTotal = new TableColumn<>("TOTAL");
        colTotal.setPrefWidth(70);
        colTotal.setStyle("-fx-font-weight: bold;");
        colTotal.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getTotal()));
        tabla.getColumns().add(colTotal);
        tabla.getColumns().add(colFoto);

        txtBuscar.textProperty().addListener((obs, old, nuevo) -> {
            pagination.setCurrentPageIndex(0);
            actualizarPaginacion(nuevo);
        });

        pagination.currentPageIndexProperty().addListener((obs, old, nuevo) -> cargarPagina(nuevo.intValue(), txtBuscar.getText()));

        actualizarPaginacion("");
    }

    private void actualizarPaginacion(String filtro){
        int total = dao.contar(filtro);
        int pageCount = (int) Math.ceil((double) total / PAGE_SIZE);
        pagination.setPageCount(pageCount==0?1:pageCount);
        cargarPagina(pagination.getCurrentPageIndex(), filtro);
        lblInfo.setText("Total modelos: " + total + " | Pagina " + (pagination.getCurrentPageIndex()+1) + "/" + pagination.getPageCount());
    }

    private void cargarPagina(int page, String filtro){
        List<Producto> datos = dao.listar(filtro, page, PAGE_SIZE);
        tabla.setItems(FXCollections.observableArrayList(datos));
    }

    private void cargarMarcas(){
        cbMarcas.setItems(FXCollections.observableArrayList(dao.listarMarcas()));
    }

    @FXML
    void onAgregarFoto(){
        Producto sel = tabla.getSelectionModel().getSelectedItem();
        if(sel==null){ alert("Selecciona un producto de la tabla"); return; }
        FileChooser fc = new FileChooser();
        fc.setTitle("Foto del modelo");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagenes","*.png","*.jpg","*.jpeg"));
        File file = fc.showOpenDialog(tabla.getScene().getWindow());
        if(file!=null){
            try{
                String destDir = "fotos";
                Files.createDirectories(Paths.get(destDir));
                String dest = destDir + "/" + sel.getId() + "_" + file.getName();
                Files.copy(file.toPath(), Paths.get(dest), StandardCopyOption.REPLACE_EXISTING);
                dao.actualizarFoto(sel.getId(), dest);
                sel.setFotoRuta(dest);
                tabla.refresh();
            }catch(Exception e){ e.printStackTrace(); }
        }
    }

    @FXML
    void onAgregarMarca(){
        String nombre = txtNuevaMarca.getText().trim();
        if(nombre.isEmpty()) return;
        dao.crearMarca(nombre.toUpperCase());
        txtNuevaMarca.clear();
        cargarMarcas();
    }

    @FXML
    void onAgregarProducto(){
        if(cbMarcas.getValue()==null || txtRef.getText().isEmpty() || txtNombre.getText().isEmpty()){
            alert("Completa marca, referencia y nombre"); return;
        }
        dao.crearProducto(txtRef.getText(), txtNombre.getText(), cbMarcas.getValue().getId());
        txtRef.clear(); txtNombre.clear();
        actualizarPaginacion(txtBuscar.getText());
    }

    void alert(String msg){ new Alert(Alert.AlertType.INFORMATION, msg).showAndWait(); }
}
